import Link from "next/link"
import { Book, Briefcase, Code, Github, Linkedin, Mail, Music, School, Scissors } from "lucide-react"
import { Button } from "@/components/ui/button"
import { Card, CardContent } from "@/components/ui/card"

export default function Home() {
  return (
    <div className="min-h-screen bg-purple-50 text-zinc-800 font-mono">
      {/* Retro Header with Pixel Art Border */}
      <header className="relative border-b-4 border-dashed border-purple-800 bg-purple-100 p-6">
        <div className="absolute inset-0 bg-[radial-gradient(#e5e7eb_1px,transparent_1px)] opacity-30 [background-size:16px_16px]"></div>
        <div className="relative max-w-5xl mx-auto">
          <nav className="flex justify-between items-center">
            <h1 className="text-2xl font-bold tracking-tight">JerolinMary.dev</h1>
            <div className="space-x-4">
              <Link href="#about" className="hover:text-purple-700 transition-colors">
                About
              </Link>
              <Link href="#experience" className="hover:text-purple-700 transition-colors">
                Experience
              </Link>
              <Link href="#education" className="hover:text-purple-700 transition-colors">
                Education
              </Link>
              <Link href="#interests" className="hover:text-purple-700 transition-colors">
                Interests
              </Link>
            </div>
          </nav>
        </div>
      </header>

      <main className="max-w-5xl mx-auto p-6 space-y-16">
        {/* Hero Section */}
        <section className="flex flex-col-reverse md:flex-row items-center gap-8 py-12">
          <div className="flex-1 space-y-4">
            <div className="inline-block px-4 py-1 bg-purple-200 border-2 border-purple-800 rounded-full text-sm font-medium mb-4">
              Data Scientist
            </div>
            <h1 className="text-4xl md:text-6xl font-bold leading-tight">Hey, I'm Jerolin Mary</h1>
            <p className="text-xl text-zinc-700">
              BE CSE Student & Data Scientist with a passion for coding, fashion design, music and literature.
            </p>
            <div className="flex gap-4 pt-4">
              <Button className="bg-purple-700 hover:bg-purple-800">
                <Mail className="mr-2 h-4 w-4" /> Contact Me
              </Button>
              <Button variant="outline" className="border-purple-700 text-purple-700 hover:bg-purple-100">
                Download Resume
              </Button>
            </div>
          </div>
          <div className="relative flex-1 aspect-square max-w-[300px]">
            <div className="absolute inset-0 border-4 border-purple-800 rounded-lg transform rotate-3 bg-purple-300"></div>
            <div className="absolute inset-0 border-4 border-purple-800 rounded-lg transform -rotate-3 bg-purple-200"></div>
            <div className="relative h-full w-full border-4 border-purple-800 rounded-lg overflow-hidden">
              <img src="/cartoon-avatar.png" alt="Jerolin Mary" className="h-full w-full object-cover" />
            </div>
          </div>
        </section>

        {/* About Section */}
        <section id="about" className="space-y-6">
          <div className="inline-flex items-center gap-2 px-4 py-1 bg-purple-200 border-2 border-purple-800 rounded-full text-sm font-medium">
            <span className="h-2 w-2 rounded-full bg-purple-800"></span>
            About Me
          </div>
          <div className="grid md:grid-cols-2 gap-8">
            <div className="space-y-4">
              <h2 className="text-3xl font-bold">Who am I?</h2>
              <p className="text-lg">
                I'm a Computer Science & Engineering student at Saveetha University with a passion for data science and
                fashion design. Currently working at Lin's Infotechs as a Data Scientist, I enjoy solving complex
                problems and extracting meaningful insights from data.
              </p>
              <p className="text-lg">
                My dream is to blend my technical skills with my creative passion for fashion design, creating
                innovative solutions at the intersection of technology and fashion. When I'm not coding or sketching
                designs, you'll find me playing my ukulele or lost in the pages of a good book.
              </p>
            </div>
            <div className="bg-purple-100 border-4 border-purple-800 rounded-lg p-6 space-y-4">
              <h3 className="text-xl font-bold">Skills</h3>
              <div className="grid grid-cols-2 gap-4">
                <div className="space-y-2">
                  <p className="font-medium">Python</p>
                  <div className="h-2 bg-purple-200 rounded-full">
                    <div className="h-2 bg-purple-700 rounded-full w-[90%]"></div>
                  </div>
                </div>
                <div className="space-y-2">
                  <p className="font-medium">Machine Learning</p>
                  <div className="h-2 bg-purple-200 rounded-full">
                    <div className="h-2 bg-purple-700 rounded-full w-[85%]"></div>
                  </div>
                </div>
                <div className="space-y-2">
                  <p className="font-medium">Data Visualization</p>
                  <div className="h-2 bg-purple-200 rounded-full">
                    <div className="h-2 bg-purple-700 rounded-full w-[80%]"></div>
                  </div>
                </div>
                <div className="space-y-2">
                  <p className="font-medium">Fashion Design</p>
                  <div className="h-2 bg-purple-200 rounded-full">
                    <div className="h-2 bg-purple-700 rounded-full w-[85%]"></div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </section>

        {/* Experience Section */}
        <section id="experience" className="space-y-6">
          <div className="inline-flex items-center gap-2 px-4 py-1 bg-purple-200 border-2 border-purple-800 rounded-full text-sm font-medium">
            <span className="h-2 w-2 rounded-full bg-purple-800"></span>
            Experience
          </div>
          <h2 className="text-3xl font-bold">Work Experience</h2>
          <Card className="border-4 border-purple-800 bg-purple-100">
            <CardContent className="p-6">
              <div className="flex flex-col md:flex-row gap-6">
                <div className="flex-shrink-0 flex items-center justify-center w-16 h-16 bg-purple-200 border-2 border-purple-800 rounded-lg">
                  <Briefcase className="h-8 w-8 text-purple-800" />
                </div>
                <div className="space-y-2">
                  <div className="flex flex-col md:flex-row md:items-center gap-2 md:gap-4">
                    <h3 className="text-xl font-bold">Data Scientist</h3>
                    <div className="px-3 py-1 bg-purple-200 border-2 border-purple-800 rounded-full text-xs font-medium inline-block">
                      Current
                    </div>
                  </div>
                  <p className="text-lg font-medium text-purple-800">Lin's Infotechs</p>
                  <p className="text-zinc-700">
                    Working on data analysis, machine learning models, and providing data-driven insights to help the
                    company make informed decisions. Collaborating with cross-functional teams to implement data science
                    solutions and exploring innovative approaches to complex problems.
                  </p>
                </div>
              </div>
            </CardContent>
          </Card>
        </section>

        {/* Education Section */}
        <section id="education" className="space-y-6">
          <div className="inline-flex items-center gap-2 px-4 py-1 bg-purple-200 border-2 border-purple-800 rounded-full text-sm font-medium">
            <span className="h-2 w-2 rounded-full bg-purple-800"></span>
            Education
          </div>
          <h2 className="text-3xl font-bold">Academic Background</h2>
          <Card className="border-4 border-purple-800 bg-purple-100">
            <CardContent className="p-6">
              <div className="flex flex-col md:flex-row gap-6">
                <div className="flex-shrink-0 flex items-center justify-center w-16 h-16 bg-purple-200 border-2 border-purple-800 rounded-lg">
                  <School className="h-8 w-8 text-purple-800" />
                </div>
                <div className="space-y-2">
                  <div className="flex flex-col md:flex-row md:items-center gap-2 md:gap-4">
                    <h3 className="text-xl font-bold">Bachelor of Engineering in Computer Science</h3>
                    <div className="px-3 py-1 bg-purple-200 border-2 border-purple-800 rounded-full text-xs font-medium inline-block">
                      Current
                    </div>
                  </div>
                  <p className="text-lg font-medium text-purple-800">Saveetha University</p>
                  <p className="text-zinc-700">
                    Focusing on computer science fundamentals, data structures, algorithms, and specialized courses in
                    data science and machine learning. Also pursuing extracurricular studies in fashion design and
                    technology integration.
                  </p>
                </div>
              </div>
            </CardContent>
          </Card>
        </section>

        {/* Interests Section */}
        <section id="interests" className="space-y-6">
          <div className="inline-flex items-center gap-2 px-4 py-1 bg-purple-200 border-2 border-purple-800 rounded-full text-sm font-medium">
            <span className="h-2 w-2 rounded-full bg-purple-800"></span>
            Interests
          </div>
          <h2 className="text-3xl font-bold">When I'm Not Coding</h2>
          <div className="grid md:grid-cols-2 gap-6">
            <Card className="border-4 border-purple-800 bg-purple-100">
              <CardContent className="p-6">
                <div className="flex gap-4 items-start">
                  <div className="flex-shrink-0 flex items-center justify-center w-12 h-12 bg-purple-200 border-2 border-purple-800 rounded-lg">
                    <Music className="h-6 w-6 text-purple-800" />
                  </div>
                  <div>
                    <h3 className="text-xl font-bold mb-2">Playing Ukulele</h3>
                    <p className="text-zinc-700">
                      I love strumming my ukulele in my free time. The cheerful sound helps me relax and express my
                      creativity outside of the tech world.
                    </p>
                  </div>
                </div>
              </CardContent>
            </Card>
            <Card className="border-4 border-purple-800 bg-purple-100">
              <CardContent className="p-6">
                <div className="flex gap-4 items-start">
                  <div className="flex-shrink-0 flex items-center justify-center w-12 h-12 bg-purple-200 border-2 border-purple-800 rounded-lg">
                    <Book className="h-6 w-6 text-purple-800" />
                  </div>
                  <div>
                    <h3 className="text-xl font-bold mb-2">Reading Books</h3>
                    <p className="text-zinc-700">
                      Books are my gateway to different worlds and perspectives. I enjoy fiction, non-fiction, and
                      technical books that expand my knowledge.
                    </p>
                  </div>
                </div>
              </CardContent>
            </Card>
            <Card className="border-4 border-purple-800 bg-purple-100">
              <CardContent className="p-6">
                <div className="flex gap-4 items-start">
                  <div className="flex-shrink-0 flex items-center justify-center w-12 h-12 bg-purple-200 border-2 border-purple-800 rounded-lg">
                    <Scissors className="h-6 w-6 text-purple-800" />
                  </div>
                  <div>
                    <h3 className="text-xl font-bold mb-2">Fashion Design</h3>
                    <p className="text-zinc-700">
                      I'm passionate about fashion design and dream of combining it with technology. I sketch designs,
                      experiment with patterns, and explore how data science can revolutionize the fashion industry.
                    </p>
                  </div>
                </div>
              </CardContent>
            </Card>
            <Card className="border-4 border-purple-800 bg-purple-100">
              <CardContent className="p-6">
                <div className="flex gap-4 items-start">
                  <div className="flex-shrink-0 flex items-center justify-center w-12 h-12 bg-purple-200 border-2 border-purple-800 rounded-lg">
                    <Code className="h-6 w-6 text-purple-800" />
                  </div>
                  <div>
                    <h3 className="text-xl font-bold mb-2">Coding Projects</h3>
                    <p className="text-zinc-700">
                      Beyond my professional work, I enjoy working on personal coding projects that challenge me and
                      allow me to explore new technologies and programming languages.
                    </p>
                  </div>
                </div>
              </CardContent>
            </Card>
          </div>
        </section>

        {/* Contact Section */}
        <section id="contact" className="space-y-6">
          <div className="inline-flex items-center gap-2 px-4 py-1 bg-purple-200 border-2 border-purple-800 rounded-full text-sm font-medium">
            <span className="h-2 w-2 rounded-full bg-purple-800"></span>
            Contact
          </div>
          <h2 className="text-3xl font-bold">Get In Touch</h2>
          <div className="grid md:grid-cols-3 gap-6">
            <Card className="border-4 border-purple-800 bg-purple-100">
              <CardContent className="p-6">
                <div className="flex flex-col items-center text-center gap-4">
                  <div className="flex-shrink-0 flex items-center justify-center w-12 h-12 bg-purple-200 border-2 border-purple-800 rounded-full">
                    <Mail className="h-6 w-6 text-purple-800" />
                  </div>
                  <div>
                    <h3 className="text-lg font-bold mb-2">Email</h3>
                    <a href="mailto:jerolinmary2006@gmail.com" className="text-purple-700 hover:underline break-all">
                      jerolinmary2006@gmail.com
                    </a>
                  </div>
                </div>
              </CardContent>
            </Card>
            <Card className="border-4 border-purple-800 bg-purple-100">
              <CardContent className="p-6">
                <div className="flex flex-col items-center text-center gap-4">
                  <div className="flex-shrink-0 flex items-center justify-center w-12 h-12 bg-purple-200 border-2 border-purple-800 rounded-full">
                    <Github className="h-6 w-6 text-purple-800" />
                  </div>
                  <div>
                    <h3 className="text-lg font-bold mb-2">GitHub</h3>
                    <a
                      href="https://github.com/Jerolin-mary"
                      target="_blank"
                      rel="noopener noreferrer"
                      className="text-purple-700 hover:underline break-all"
                    >
                      github.com/Jerolin-mary
                    </a>
                  </div>
                </div>
              </CardContent>
            </Card>
            <Card className="border-4 border-purple-800 bg-purple-100">
              <CardContent className="p-6">
                <div className="flex flex-col items-center text-center gap-4">
                  <div className="flex-shrink-0 flex items-center justify-center w-12 h-12 bg-purple-200 border-2 border-purple-800 rounded-full">
                    <Linkedin className="h-6 w-6 text-purple-800" />
                  </div>
                  <div>
                    <h3 className="text-lg font-bold mb-2">LinkedIn</h3>
                    <a
                      href="https://www.linkedin.com/in/jerolin-mary-bb8246298/"
                      target="_blank"
                      rel="noopener noreferrer"
                      className="text-purple-700 hover:underline break-all"
                    >
                      linkedin.com/in/jerolin-mary-bb8246298
                    </a>
                  </div>
                </div>
              </CardContent>
            </Card>
          </div>
        </section>
      </main>

      {/* Footer */}
      <footer className="bg-purple-100 border-t-4 border-dashed border-purple-800 p-6 mt-16">
        <div className="max-w-5xl mx-auto flex flex-col md:flex-row justify-between items-center gap-4">
          <p className="text-center md:text-left">
            © {new Date().getFullYear()} Jerolin Mary | Data Scientist & Developer
          </p>
          <div className="flex gap-4">
            <a href="mailto:jerolinmary2006@gmail.com" aria-label="Email">
              <Button
                variant="outline"
                size="icon"
                className="rounded-full border-purple-800 text-purple-800 hover:bg-purple-200"
              >
                <Mail className="h-5 w-5" />
              </Button>
            </a>
            <a
              href="https://www.linkedin.com/in/jerolin-mary-bb8246298/"
              target="_blank"
              rel="noopener noreferrer"
              aria-label="LinkedIn"
            >
              <Button
                variant="outline"
                size="icon"
                className="rounded-full border-purple-800 text-purple-800 hover:bg-purple-200"
              >
                <Linkedin className="h-5 w-5" />
              </Button>
            </a>
            <a href="https://github.com/Jerolin-mary" target="_blank" rel="noopener noreferrer" aria-label="GitHub">
              <Button
                variant="outline"
                size="icon"
                className="rounded-full border-purple-800 text-purple-800 hover:bg-purple-200"
              >
                <Github className="h-5 w-5" />
              </Button>
            </a>
          </div>
        </div>
      </footer>

      {/* Retro Grain Overlay */}
      <div className="fixed inset-0 pointer-events-none bg-[url('data:image/svg+xml;base64,PHN2ZyB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciIHdpZHRoPSIzMDAiIGhlaWdodD0iMzAwIj48ZmlsdGVyIGlkPSJhIiB4PSIwIiB5PSIwIj48ZmVUdXJidWxlbmNlIGJhc2VGcmVxdWVuY3k9Ii43NSIgc3RpdGNoVGlsZXM9InN0aXRjaCIgdHlwZT0iZnJhY3RhbE5vaXNlIi8+PGZlQ29sb3JNYXRyaXggdHlwZT0ic2F0dXJhdGUiIHZhbHVlcz0iMCIvPjwvZmlsdGVyPjxwYXRoIGQ9Ik0wIDBoMzAwdjMwMEgweiIgZmlsdGVyPSJ1cmwoI2EpIiBvcGFjaXR5PSIuMDUiLz48L3N2Zz4=')]"></div>
    </div>
  )
}

